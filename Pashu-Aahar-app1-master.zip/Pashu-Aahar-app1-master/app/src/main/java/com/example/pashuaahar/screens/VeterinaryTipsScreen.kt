package com.example.pashuaahar.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Tip(
    val title: String,
    val description: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VeterinaryTipsScreen() {

    var searchText by remember {
        mutableStateOf("")
    }

    val tips = listOf(

        Tip(
            "Clean Water",
            "Provide clean drinking water daily."
        ),

        Tip(
            "Vaccination",
            "Vaccinate cows regularly to prevent diseases."
        ),

        Tip(
            "Balanced Feed",
            "Use green fodder and mineral mixture."
        ),

        Tip(
            "Clean Shelter",
            "Maintain hygienic cattle sheds."
        ),

        Tip(
            "Regular Checkup",
            "Consult veterinarians regularly."
        ),

        Tip(
            "Deworming",
            "Perform deworming every few months."
        ),

        Tip(
            "Heat Protection",
            "Protect cattle from excess summer heat."
        ),

        Tip(
            "Daily Exercise",
            "Allow cows to walk daily."
        ),

        Tip(
            "Clean Equipment",
            "Wash feeding equipment regularly."
        ),

        Tip(
            "Ventilation",
            "Maintain fresh air circulation in sheds."
        )
    )

    Scaffold(

        topBar = {

            TopAppBar(
                title = {

                    Text(
                        text = "Veterinary Tips",
                        fontWeight = FontWeight.Bold
                    )
                }
            )
        }

    ) { paddingValues ->

        LazyColumn(

            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),

            verticalArrangement = Arrangement.spacedBy(12.dp),

            contentPadding = PaddingValues(bottom = 40.dp)

        ) {

            item {

                OutlinedTextField(
                    value = searchText,
                    onValueChange = {
                        searchText = it
                    },

                    label = {
                        Text("Search Tips")
                    },

                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))
            }

            items(tips) { tip ->

                Card(
                    modifier = Modifier.fillMaxWidth()
                ) {

                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {

                        Text(
                            text = tip.title,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = tip.description,
                            fontSize = 18.sp
                        )
                    }
                }
            }
        }
    }
}