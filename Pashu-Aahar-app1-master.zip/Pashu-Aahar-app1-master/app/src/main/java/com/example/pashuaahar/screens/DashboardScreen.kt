package com.example.pashuaahar.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.pashuaahar.R

data class DashboardItem(
    val title: String,
    val description: String,
    val icon: ImageVector
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(navController: NavHostController) {

    val features = listOf(

        DashboardItem(
            stringResource(R.string.cow_profile),
            "Store breed, age, weight and milk yield.",
            Icons.Default.AccountCircle
        ),

        DashboardItem(
            stringResource(R.string.feed_generator),
            "Generate smart cattle feed recipes.",
            Icons.Default.List
        ),

        DashboardItem(
            stringResource(R.string.cost_tracker),
            "Track feed expenses and savings.",
            Icons.Default.ShoppingCart
        ),

        DashboardItem(
            stringResource(R.string.veterinary_tips),
            "View health and hygiene tips.",
            Icons.Default.Info
        ),

        DashboardItem(
            "Language",
            "Select app language.",
            Icons.Default.Info
        )
    )

    Scaffold(

        containerColor = Color(0xFFF8F5FF),

        topBar = {

            TopAppBar(

                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFF8F5FF)
                ),

                title = {

                    Text(
                        text = stringResource(R.string.dashboard),
                        fontWeight = FontWeight.Bold,
                        fontSize = 28.sp
                    )
                },

                actions = {

                    TextButton(
                        onClick = {

                            navController.navigate("login")
                        }
                    ) {

                        Text("Logout")
                    }
                }
            )
        }

    ) { paddingValues ->

        LazyColumn(

            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),

            verticalArrangement = Arrangement.spacedBy(20.dp),

            contentPadding = PaddingValues(
                top = 20.dp,
                bottom = 40.dp
            )

        ) {

            items(features) { item ->

                if(item.title == "Language") {

                    SmallLanguageCard(navController)

                } else {

                    Card(

                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(
                                elevation = 6.dp,
                                shape = RoundedCornerShape(24.dp)
                            )
                            .clickable {

                                when(item.title) {

                                    "Cow Profile",
                                    "ಹಸು ಮಾಹಿತಿ" ->
                                        navController.navigate("profile")

                                    "Feed Generator",
                                    "ಆಹಾರ ತಯಾರಕ" ->
                                        navController.navigate("feed")

                                    "Cost Tracker",
                                    "ವೆಚ್ಚ ಟ್ರ್ಯಾಕರ್" ->
                                        navController.navigate("cost")

                                    "Veterinary Tips",
                                    "ಪಶುವೈದ್ಯ ಸಲಹೆಗಳು" ->
                                        navController.navigate("tips")
                                }
                            },

                        shape = RoundedCornerShape(24.dp),

                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFFE9DDFB)
                        )
                    ) {

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),

                            verticalAlignment = Alignment.CenterVertically
                        ) {

                            Card(
                                shape = RoundedCornerShape(50.dp),

                                colors = CardDefaults.cardColors(
                                    containerColor = Color(0xFF5E35B1)
                                )
                            ) {

                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.title,

                                    tint = Color.White,

                                    modifier = Modifier
                                        .padding(14.dp)
                                        .size(30.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(20.dp))

                            Column {

                                Text(
                                    text = item.title,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E1065)
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = item.description,
                                    fontSize = 17.sp,
                                    color = Color.DarkGray
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SmallLanguageCard(navController: NavHostController) {

    Card(

        modifier = Modifier
            .width(170.dp)
            .height(70.dp)
            .clickable {

                navController.navigate("language")
            },

        shape = RoundedCornerShape(20.dp),

        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFD1C4E9)
        )
    ) {

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),

            verticalAlignment = Alignment.CenterVertically
        ) {

            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "Language"
            )

            Spacer(modifier = Modifier.width(10.dp))

            Text(
                text = "Language",
                fontWeight = FontWeight.Bold
            )
        }
    }
}