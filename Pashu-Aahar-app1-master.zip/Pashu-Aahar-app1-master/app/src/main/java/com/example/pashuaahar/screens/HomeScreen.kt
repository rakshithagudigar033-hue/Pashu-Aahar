package com.example.pashuaahar.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier

@Composable
fun HomeScreen() {

    var selectedScreen by remember {
        mutableStateOf(0)
    }

    Scaffold(

        bottomBar = {

            NavigationBar {

                NavigationBarItem(
                    selected = selectedScreen == 0,
                    onClick = {
                        selectedScreen = 0
                    },
                    icon = {
                        Icon(Icons.Default.Person, contentDescription = "Profile")
                    },
                    label = {
                        Text("Profile")
                    }
                )

                NavigationBarItem(
                    selected = selectedScreen == 1,
                    onClick = {
                        selectedScreen = 1
                    },
                    icon = {
                        Icon(Icons.Default.List, contentDescription = "Feed")
                    },
                    label = {
                        Text("Feed")
                    }
                )

                NavigationBarItem(
                    selected = selectedScreen == 2,
                    onClick = {
                        selectedScreen = 2
                    },
                    icon = {
                        Icon(Icons.Default.Home, contentDescription = "Cost")
                    },
                    label = {
                        Text("Cost")
                    }
                )

                NavigationBarItem(
                    selected = selectedScreen == 3,
                    onClick = {
                        selectedScreen = 3
                    },
                    icon = {
                        Icon(Icons.Default.Info, contentDescription = "Tips")
                    },
                    label = {
                        Text("Tips")
                    }
                )
            }
        }

    ) { paddingValues ->

        Surface(
            modifier = Modifier.padding(paddingValues)
        ) {

            when (selectedScreen) {

                0 -> CowProfileScreen()

                1 -> FeedGeneratorScreen()

                2 -> CostTrackerScreen()

                3 -> VeterinaryTipsScreen()
            }
        }
    }
}