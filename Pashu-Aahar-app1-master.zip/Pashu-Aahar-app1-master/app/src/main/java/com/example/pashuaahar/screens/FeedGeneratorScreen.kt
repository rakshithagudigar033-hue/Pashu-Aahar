package com.example.pashuaahar.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun FeedGeneratorScreen() {

    var milkYield by remember { mutableStateOf("") }

    var result by remember {
        mutableStateOf("Feed recipe will appear here")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),

        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            text = "Feed Generator",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = milkYield,
            onValueChange = {
                milkYield = it
            },
            label = {
                Text("Milk Yield")
            },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {

                val milk = milkYield.toDoubleOrNull()

                result = if (milk == null) {

                    "Enter valid milk yield"

                } else if (milk < 5) {

                    """
Feed Recipe:

• 2kg Maize
• 1kg Cottonseed Cake
• Green Fodder
                    """.trimIndent()

                } else {

                    """
Feed Recipe:

• 4kg Maize
• 2kg Cottonseed Cake
• Mineral Mix
• Green Fodder
                    """.trimIndent()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {

            Text("Generate Feed")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Card(
            modifier = Modifier.fillMaxWidth()
        ) {

            Text(
                text = result,
                modifier = Modifier.padding(16.dp),
                fontSize = 18.sp
            )
        }
    }
}