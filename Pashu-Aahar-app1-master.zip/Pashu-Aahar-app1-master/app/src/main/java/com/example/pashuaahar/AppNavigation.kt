package com.example.pashuaahar

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.pashuaahar.screens.*

@Composable
fun AppNavigation() {

    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "login"
    ) {

        composable("login") {
            LoginScreen(navController)
        }

        composable("signup") {
            SignupScreen(navController)
        }

        composable("dashboard") {
            DashboardScreen(navController)
        }

        composable("profile") {
            CowProfileScreen()
        }

        composable("feed") {
            FeedGeneratorScreen()
        }

        composable("cost") {
            CostTrackerScreen()
        }

        composable("tips") {
            VeterinaryTipsScreen()
        }

        composable("language") {
            LanguageScreen()
        }
    }
}