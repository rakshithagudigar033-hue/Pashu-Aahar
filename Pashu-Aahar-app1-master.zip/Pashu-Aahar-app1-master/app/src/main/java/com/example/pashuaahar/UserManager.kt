package com.example.pashuaahar

object UserManager {

    var savedEmail = ""
    var savedPassword = ""
}