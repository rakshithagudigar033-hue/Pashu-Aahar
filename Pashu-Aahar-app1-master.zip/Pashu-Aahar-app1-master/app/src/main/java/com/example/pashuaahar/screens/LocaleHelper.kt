package com.example.pashuaahar

import android.app.Activity
import android.content.res.Configuration
import java.util.*

object LocaleHelper {

    fun setLocale(activity: Activity, languageCode: String) {

        val locale = Locale(languageCode)

        Locale.setDefault(locale)

        val config = Configuration()

        config.setLocale(locale)

        activity.resources.updateConfiguration(
            config,
            activity.resources.displayMetrics
        )
    }
}