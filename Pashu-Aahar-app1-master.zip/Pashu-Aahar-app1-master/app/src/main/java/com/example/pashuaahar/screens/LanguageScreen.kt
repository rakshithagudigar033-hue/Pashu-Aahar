package com.example.pashuaahar.screens

import android.app.Activity
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pashuaahar.LocaleHelper
import com.example.pashuaahar.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguageScreen() {

    val context = LocalContext.current
    val activity = context as Activity

    var selectedLanguage by remember {
        mutableStateOf("English")
    }

    Scaffold(

        topBar = {

            TopAppBar(

                title = {

                    Text(
                        text = stringResource(R.string.language_selection),
                        fontWeight = FontWeight.Bold
                    )
                },

                navigationIcon = {

                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Language",
                        modifier = Modifier.padding(start = 12.dp)
                    )
                }
            )
        }

    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(20.dp),

            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Spacer(modifier = Modifier.height(40.dp))

            Text(
                text = stringResource(R.string.language_selection),
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(40.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),

                onClick = {

                    selectedLanguage = "English"
                }
            ) {

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),

                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Text(
                        text = "English",
                        fontSize = 22.sp
                    )

                    RadioButton(
                        selected = selectedLanguage == "English",
                        onClick = {

                            selectedLanguage = "English"
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),

                onClick = {

                    selectedLanguage = "Kannada"
                }
            ) {

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),

                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Text(
                        text = "ಕನ್ನಡ",
                        fontSize = 22.sp
                    )

                    RadioButton(
                        selected = selectedLanguage == "Kannada",
                        onClick = {

                            selectedLanguage = "Kannada"
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(40.dp))

            Button(
                onClick = {

                    if(selectedLanguage == "English") {

                        LocaleHelper.setLocale(activity, "en")

                    } else {

                        LocaleHelper.setLocale(activity, "kn")
                    }

                    activity.recreate()
                },

                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    text = stringResource(R.string.save_language),
                    fontSize = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Selected Language : $selectedLanguage",
                fontSize = 18.sp
            )
        }
    }
}