package com.example.pashuaahar.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CostTrackerScreen() {

    var homeFeedCost by remember { mutableStateOf("") }
    var marketFeedCost by remember { mutableStateOf("") }

    var result by remember {
        mutableStateOf("Savings result will appear here")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),

        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            text = "Cost Tracker",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = homeFeedCost,
            onValueChange = {
                homeFeedCost = it
            },
            label = {
                Text("Home Feed Cost")
            },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = marketFeedCost,
            onValueChange = {
                marketFeedCost = it
            },
            label = {
                Text("Market Feed Cost")
            },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {

                val home = homeFeedCost.toDoubleOrNull()
                val market = marketFeedCost.toDoubleOrNull()

                result = if (home == null || market == null) {

                    "Enter valid costs"

                } else {

                    val savings = market - home

                    """
Home Feed Cost : ₹$home

Market Feed Cost : ₹$market

Total Savings : ₹$savings
                    """.trimIndent()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {

            Text("Calculate Savings")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Card(
            modifier = Modifier.fillMaxWidth()
        ) {

            Text(
                text = result,
                modifier = Modifier.padding(16.dp),
                fontSize = 18.sp
            )
        }
    }
}